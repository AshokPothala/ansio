import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spclevents',
  templateUrl: './spclevents.component.html',
  styleUrls: ['./spclevents.component.css']
})
export class SpcleventsComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
