import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpcleventsComponent } from './spclevents.component';

describe('SpcleventsComponent', () => {
  let component: SpcleventsComponent;
  let fixture: ComponentFixture<SpcleventsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpcleventsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpcleventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
