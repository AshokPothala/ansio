import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import{Router} from '@angular/router'

@Component({
  selector: 'app-listusers',
  templateUrl: './listusers.component.html',
  styleUrls: ['./listusers.component.css']
})
export class ListusersComponent implements OnInit {
  userslist: any;

  constructor(private auth : AuthService, private router :Router ) { }

  
  ngOnInit(): void {
    this.auth.getallusers().subscribe(data=> 
      this.userslist = data,
      err=>{
        if(err instanceof HttpErrorResponse){
          if(err.status === 401){
              this.router.navigate(['/login'])
          }
        }
      }
      
      );
  }



}
