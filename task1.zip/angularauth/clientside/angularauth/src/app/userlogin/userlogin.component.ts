import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import{Router} from '@angular/router'

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  loginUserData = {
    email: "",
    password: ""
  }
  
  constructor(private auth : AuthService,private router :Router) { }

  ngOnInit(): void {
  }
  loginUser(){
this.auth.loginuser(this.loginUserData).subscribe(data=>{
  console.log(data)
  localStorage.setItem('token',data.token)
  this.router.navigate(['/users']);

},
error=>console.log(error)

)
  }

}
