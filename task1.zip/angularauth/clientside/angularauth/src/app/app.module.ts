import { NgModule } from '@angular/core';
import { HttpClientModule ,HTTP_INTERCEPTORS} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserevntsComponent } from './userevnts/userevnts.component';
import { SpcleventsComponent } from './spclevents/spclevents.component';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth.service';
import { ListusersComponent } from './listusers/listusers.component';
import {InterceptorService} from './interceptor.service'


@NgModule({
  declarations: [
    AppComponent,
    UserregisterComponent,
    UserloginComponent,
    UserevntsComponent,
    SpcleventsComponent,
    ListusersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    AuthService,
  {
    provide: HTTP_INTERCEPTORS,
    useClass:InterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
