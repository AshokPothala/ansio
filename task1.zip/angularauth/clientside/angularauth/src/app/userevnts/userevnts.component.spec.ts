import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserevntsComponent } from './userevnts.component';

describe('UserevntsComponent', () => {
  let component: UserevntsComponent;
  let fixture: ComponentFixture<UserevntsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserevntsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserevntsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
