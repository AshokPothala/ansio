import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userevnts',
  templateUrl: './userevnts.component.html',
  styleUrls: ['./userevnts.component.css']
})
export class UserevntsComponent implements OnInit {

  constructor() { }

  
  ngOnInit(): void {
  }

}
