import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { AuthService } from '../auth.service';
import{Router} from '@angular/router'

@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css']
})
export class UserregisterComponent implements OnInit {
  registerUserData = {
    email: "",
    password: "",
    username:""
  }
  constructor(private auth : AuthService, private router :Router) { }

  ngOnInit(): void {
  }
registerUser(){
this.auth.registeruser(this.registerUserData).subscribe(data=>{
  console.log(data)
  localStorage.setItem('token',data.token)
  this.router.navigate(['/login'])

},
    error=>console.log(error)

)
  }
}