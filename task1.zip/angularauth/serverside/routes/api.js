const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const User = require('../models/user')

const mongoose = require('mongoose');
const user = require('../models/user');
const db = "mongodb+srv://user:user@cluster0.tajsn.mongodb.net/eventsDB?retryWrites=true&w=majority"

mongoose.connect(db, err =>{
    if(err){
        console.log("Error: "+ err)
    }else{
        console.log("database connected successfully")
    }
});


router.get('/', (req,res)=>{
res.send("From Api Route")
});

router.post('/register',(req,res)=>{
let userdata = req.body
let user = new User(userdata);
user.save((error, registreduser)=>{
    if(error){
        console.log("Error: "+error)
    }else{
        let payload = {subject:registreduser._id}
        let token = jwt.sign(payload,'mysecretkey')
        res.status(200).send({token})
    }
})
});


function verifyToken(req,res,next){

    if(!req.headers.authorization){
        return res.status(401).send('Unauthorized request')
    }
    console.log(req.headers.authorization,"mmmmmmmmm")
    var token = req.headers.authorization.split(' ')[1];
console.log(token,"nnnnnnnnn")
    if(token === null){
        return res.status(401).send('Unauthorized request')

    }

    let payload = jwt.verify(token, 'mysecretkey')
    if(!payload){
        return res.status(401).send('Unauthorized request')

    }
    req.userId =payload.subject
    next()
}

router.post('/login',(req,res)=>{
let userdata = req.body;
User.findOne({email:userdata.email},(error,user)=>{
    if(error){
        console.log("Error:" + error)
    }else{
        if(!user){
            res.status(401).send("Invalid Email")
        }
        else if(user.password !== userdata.password){
            res.status(401).send("Invalid password")

        }else{
            let payload ={subject:userdata._id}
            let token = jwt.sign(payload,'mysecretkey')
            res.status(200).send({token})
        }
    }
})

});

router.get('/users',verifyToken, (req,res)=>{

    User.find().then((Result) => {
        if (Result == null) {
            res.status(401).send("No Data")
        } else  {
            res.status(200).send(Result)
        }
    })

});


module.exports = router;